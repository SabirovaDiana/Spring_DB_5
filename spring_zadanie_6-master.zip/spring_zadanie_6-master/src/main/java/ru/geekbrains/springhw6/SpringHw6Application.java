package ru.geekbrains.springhw6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHw6Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringHw6Application.class, args);
    }

}
